/**Circle is an object that stores properties of a circle and can calculate other properties 
 * of a circle
 *
 *@author: Zachary Norman
 *@date: 8/30/17
 */	

import java.lang.Math;

public class Circle{
	
	//fields
	private double x, y, radius;

	
	//constructors
	public Circle(double x, double y, double radius){
		this.x = x;
		this.y = y;
		this.radius = radius;
	}
	
	
	//public methods
	
	/**getArea() uses the circle's stored info to return its area
	 *
	 *@params: none
	 *@return: (double) area of circle
	 */
	public double getArea(){
		return radius*radius*Math.PI;
	}
	
	/**getPerimeter() uses the circle's stored info to return its circumference
	 *
	 *@params: none
	 *@return: (double) circumference of circle
	 */
	public double getPerimeter(){
		return 2*radius*Math.PI;
	}

	/**toString() returns the circle's properties as a string
	 *
	 *@params: none
	 *@return: (String) circle's properties
	 */
	public String toString(){
		return "This circle's center is at x: "+x+", y: "+y+". Its radius is "+radius+". Its area is "+getArea()+". Its perimeter is "+getPerimeter()+".";
	}
		
		
	//setters/getters	
	public void setX(double x){this.x = x;}
	public void setY(double y){this.y = y;}
	public void setRadius(double radius){this.radius = radius;}
	
	public double getX(){return x;}
	public double getY(){return y;}
	public double getRadius(){return radius;}
}