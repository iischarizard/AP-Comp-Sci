/**CountingToTen is a program that counts to 10
 *
 * @author: Zachary Norman
 * @version: 1
 * @date: 8/18/17
 */
public class CountingToTen{

  public static void main(String[] args){
  	System.out.println("1");
  	System.out.println("2");
  	System.out.println("3");
  	System.out.println("4");
  	System.out.println("5");
  	System.out.println("6");
  	System.out.println("7");
  	System.out.println("8");
  	System.out.println("9");
  	System.out.println("10");
  }
  
  
}