 
public class HelloWorld{

	public static void main(String[] args){
		System.out.println("Hell world");
		System.out.println("H\ne\nl\nl\no\n \nW\no\nr\nl\nd");
	}

}